ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('yldrmm:paraver')
AddEventHandler('yldrmm:paraver', function()
	local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    xPlayer.addMoney(Config.OdulParasi)
end)

RegisterServerEvent('log:uret')
AddEventHandler('log:uret', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local playerName = Sanitize(xPlayer.getName())

    yldrmmmesleklog(xPlayer,playerName.. ' Adlı Kişi Hapis Mesleğinde Malzeme Üretti | URETME DURUMU TRUE')
end)

RegisterServerEvent('log:isle')
AddEventHandler('log:isle', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local playerName = Sanitize(xPlayer.getName())
    
    yldrmmmesleklog(xPlayer,playerName.. ' Adlı Kişi Hapis Mesleğinde Malzemeyi Pişirdi | PISIRME DURUMU TRUE')
end)

RegisterServerEvent('log:paketle')
AddEventHandler('log:paketle', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local playerName = Sanitize(xPlayer.getName())

    yldrmmmesleklog(xPlayer,playerName.. ' Adlı Kişi Hapis Mesleğinde Malzemeyi Paketledi | PAKETLEME DURUMU TRUE')
end)

RegisterServerEvent('log:sat')
AddEventHandler('log:sat', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local playerName = Sanitize(xPlayer.getName())

    yldrmmmesleklog(xPlayer,playerName.. ' Adlı Kişi Hapis Mesleğinde Malzemeyi Sattı ve 5$ Kazandı | TUM DURUMLAR SIFIRLANDI')
end)

function yldrmmmesleklog(xPlayer, text)
    local playerName = Sanitize(xPlayer.getName())

    local discord_webhook = Config.Weebhok -- DEĞİŞTİR
    if discord_webhook == '' then
      return
    end
    local headers = {
      ['Content-Type'] = 'application/json'
    }
    local data = {
      ["username"] = "Yldrmm Log System", -- DEĞİŞTİR
      ["avatar_url"] = "https://cdn.discordapp.com/icons/788829276534865961/2296c148e7aaf4c6d067138a53fadf2b.png?size=128", -- DEĞİŞTİR
      ["embeds"] = {{
        ["author"] = {
          ["name"] = playerName .. ' - ' .. xPlayer.identifier 
        },
        ["color"] = 1942002,
        ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
      }}
    }
    data['embeds'][1]['description'] = text
    PerformHttpRequest(Config.DiscordWeebhok, function(err, text, headers) end, 'POST', json.encode(data), headers)
end

function Sanitize(str)
    local replacements = {
        ['&' ] = '&amp;',
        ['<' ] = '&lt;',
        ['>' ] = '&gt;',
        ['\n'] = '<br/>'
    }

    return str
        :gsub('[&<>\n]', replacements)
        :gsub(' +', function(s)
            return ' '..('&nbsp;'):rep(#s-1)
        end)
end
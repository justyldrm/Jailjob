ESX = nil

local PlayerData = {}
local uret = false
local isle = false
local bitir = false
local uretbitti = false
local islebitti = false
local sat = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
        PlayerData = ESX.GetPlayerData()
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        for k,v in pairs(Config.Uret) do
            if uretbitti == false then
                if Vdist2(GetEntityCoords(GetPlayerPed(-1), false), v.x, v.y, v.z) < 1.5 then
                    DrawText3D(v.x, v.y, v.z, '[E] Malzemeyi Üret')
                    if IsControlJustPressed(0, 38) then
                        ClearPedSecondaryTask(PlayerPedId())
                        loadAnimDict( "mini@repair" ) 
                        TaskPlayAnim( PlayerPedId(), "mini@repair", "fixing_a_ped", 8.0, 1.0, -1, 16, 0, 0, 0, 0 )
                        exports["np-taskbar"]:taskBar(10000,"Malzeme Üretiliyor")
                        TriggerEvent('notification' , 'Üretim bitti şimdi pişirebilirsin!' , 1)
                        TriggerServerEvent('log:uret')
                        uret = true
                        uretbitti = true
                    end
                end
            end
        end
    end 
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        for k,v in pairs(Config.Isle) do
            if islebitti == false then
                if uret == true then
                    if Vdist2(GetEntityCoords(GetPlayerPed(-1), false), v.x, v.y, v.z) < 1.5 then
                        DrawText3D(v.x, v.y, v.z, '[E] Malzemeyi Pisir')
                        if IsControlJustPressed(0, 38) then
                            ClearPedSecondaryTask(PlayerPedId())
                            loadAnimDict( "mini@repair" ) 
                            TaskPlayAnim( PlayerPedId(), "mini@repair", "fixing_a_ped", 8.0, 1.0, -1, 16, 0, 0, 0, 0 )
                            exports["np-taskbar"]:taskBar(10000,"Malzeme Pişiriliyor")
                            TriggerEvent('notification' , 'Malzeme Pişirildi! Şimdi Paketle' , 1)
                            TriggerServerEvent('log:isle')
                            isle = true
                            islebitti = true
                        end
                    end
                end
            end
        end
    end 
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        for k,v in pairs(Config.Bitir) do
            if bitir == false then
                if isle == true then
                    if Vdist2(GetEntityCoords(GetPlayerPed(-1), false), v.x, v.y, v.z) < 1.5 then
                        DrawText3D(v.x, v.y, v.z, '[E] Malzemeyi Paketle')
                        if IsControlJustPressed(0, 38) then
                            ClearPedSecondaryTask(PlayerPedId())
                            loadAnimDict( "mini@repair" ) 
                            TaskPlayAnim( PlayerPedId(), "mini@repair", "fixing_a_ped", 8.0, 1.0, -1, 16, 0, 0, 0, 0 )
                            exports["np-taskbar"]:taskBar(10000,"Malzemeyi Paketliyorsun.")
                            TriggerEvent('notification' , 'Malzeme Paketlendi Şimdi Sat' , 1)
                            TriggerServerEvent('log:paketle')
                            bitir = true
                        end
                    end
                end
            end
        end
    end 
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        for k,v in pairs(Config.Sat) do
            if sat == false then
                if bitir == true then
                    if Vdist2(GetEntityCoords(GetPlayerPed(-1), false), v.x, v.y, v.z) < 1.5 then
                        DrawText3D(v.x, v.y, v.z, '[E] Malzemeyi Sat')
                        if IsControlJustPressed(0, 38) then
                            ClearPedSecondaryTask(PlayerPedId())
                            loadAnimDict( "mini@repair" ) 
                            TaskPlayAnim( PlayerPedId(), "mini@repair", "fixing_a_ped", 8.0, 1.0, -1, 16, 0, 0, 0, 0 )
                            exports["np-taskbar"]:taskBar(10000,"Malzemeyi Satıyorsun.")
                            TriggerEvent('notification' , 'Malzeme Satıldı! 5$ Kazandın.' , 1)
                            TriggerServerEvent("yldrmm:paraver")
                            TriggerServerEvent('log:sat')
                            isle = false
                            islebitti = false
                            uret = false
                            uretbitti = false
                            bitir = false
                        end
                    end
                end
            end
        end
    end 
end)

function DrawText3D(x,y,z,text,size)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)

    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end

function loadAnimDict( dict )
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 0 )
    end
end
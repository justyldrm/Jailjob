Config = {}

Config.Uret = {
    {x = 1779.710, y = 2593.839, z = 45.723}, -- ÜRETME  YERİ
}

Config.Isle = {
    {x = 1777.978, y = 2593.708, z = 45.723}, -- PİŞİRME YERİ
}

Config.Bitir = {
    {x = 1777.041, y = 2589.120, z = 45.723}, -- PAKETLEME YERİ
}

Config.Sat = {
    {x = 1776.389, y = 2589.708, z = 45.723}, -- SATMA YERİ
}

Config.DiscordWeebhok = "https://discord.com/api/webhooks/805914371863216138/F57-q1sKr17m5drYcJrrJStyF6BwtRQ10yMNxycsni3QZsWbau43B9FnxK6fhSDFA-NJ"

Config.OdulParasi = 5


